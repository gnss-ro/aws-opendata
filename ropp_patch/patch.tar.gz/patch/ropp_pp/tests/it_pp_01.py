# does a ROPP PP test
# adapted from it_pp_01.pro
#
# INPUT:
#
# KEYWORDS:
#
# OUTPUT:
#  error          1 [error] 0 [all fine]

from netCDF4 import Dataset
import numpy as np
from matplotlib import pyplot as plt
import argparse


def it_pp_01(tfile, ofile):

    #file settings 
    if len(ofile)==0:
        #TODO: remove this?
        #NOTE: must be inside /ropp_pp/tests/ for this to work
        #it not, change path
        ofile = '../data/ropp_pp_test.nc' #observations
    if len(tfile) == 0:
        tfile = '../data/ropp_pp_test_1m_reference.nc' #output

    # read the original file
    print('Reading original file ', ofile)
    id = Dataset(ofile)
    ovars = {'impact':[], 'bangle':[], 'alt_refrac':[],'refrac':[]}
    for var in ovars.keys():
        try: 
            ovars[var]=id[var]
        except KeyError:
            print('Variable not found: ', var)
        

    # read the reference file
    print('Reading the reference file ', tfile)
    id = Dataset(tfile)
    tvars = {'impact':[], 'bangle':[], 'alt_refrac':[],'refrac':[]}
    for var in tvars.keys():
        try: 
            tvars[var]=id[var]
        except KeyError:
            print('Variable not found: ', var)

    oimpact, obangle, ogeom, orefrac = ovars['impact'][0], ovars['bangle'][0], ovars['alt_refrac'][0], ovars['refrac'][0]
    timpact, tbangle, tgeom, trefrac = tvars['impact'][0], tvars['bangle'][0], tvars['alt_refrac'][0], tvars['refrac'][0]

    ifail = 0
    no1b = len(oimpact)
    no2a=len(ogeom)
    nt1b=len(timpact)
    nt2a=len(tgeom)

    print('No. Level 1b levels:',no1b,nt1b)
    print('No. Level 2a levels:',no2a,nt2a)

    # Interpolate data onto common levels
    #TODO: this doesn't seem like it's creating an actual grid, should it be?
    grid1b = min(oimpact)+np.arange(1500) * (0.7*(max(oimpact) - min(oimpact)))/1500.0
    tbangle = np.interp(grid1b, tbangle, timpact)
    timpact = np.interp(grid1b, timpact, timpact)
    obangle = np.interp(grid1b, obangle, oimpact)
    oimpact = np.interp(grid1b, oimpact, oimpact)

    grid2a = min(ogeom) + np.arange(1500) * (0.7*(max(ogeom) - min(ogeom)))/1500.0
    trefrac = np.interp(grid2a, trefrac, tgeom)
    tgeom = np.interp(grid2a, tgeom, tgeom)
    orefrac = np.interp(grid2a, orefrac, ogeom)
    ogeom = np.interp(grid2a, ogeom, ogeom)

    # Compute maximum differences between data

    diff = max( (oimpact - timpact)/oimpact)*100
    if diff>0.5:
        print('Impact parameters differ bby ', diff, '% - TEST FAILED')
        ifail = 1
    else:
        print('Impact parameters differ by ', diff, '% - TEST PASSED')


    diff = max( (obangle - tbangle))
    if diff > 0.05:
        print('Corrected bending angles differ by ', diff, 'rad - TEST FAILED')
        ifail = 1
    else:
        print('Corrected bending angles differ by ', diff, 'rad - TEST PASSED')

    diff = max(((ogeom - tgeom)/ogeom)*100.)
    if diff > 0.01:
        print('Geometric heights differ by ', diff, '% - TEST FAILED')
        ifail = 1
    else:
        print('Geometric heights differ by ', diff, '% - TEST PASSED')

    diff = max(((orefrac - trefrac)/orefrac)*100.)
    if diff > 1.0:
        print('Refractivity differ by ', diff, '% - TEST FAILED')
        ifail = 1
    else:
        print('Refractivity differ by ', diff, '% - TEST PASSED')

    jpgfile = 'ropp_pp_comp.jpg'
    fig, axs = plt.subplots(ncols=2, figsize=(12,5))

    #TODO: set resolution
    axs[0].plot((obangle - tbangle), (grid1b-min(grid1b))/1000.0, linewidth=0.5, color='black')
    axs[0].set_xlabel("Bending angle difference (rad)")
    axs[0].set_ylabel("Impact height [x-R] (km)")
    axs[1].plot(((orefrac - trefrac)/orefrac)*100., grid2a/1000.0, linewidth=0.5, color='black')
    axs[1].set_xlabel("Refractivity difference (%)")
    axs[1].set_ylabel("Geopotential height (km)") 

    plt.savefig(jpgfile)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--ofile', default='', help='output file')
    parser.add_argument('--tfile', default='', help='reference file')

    args = parser.parse_args()

    ofile = args.ofile
    tfile = args.tfile

    it_pp_01(tfile, ofile)



