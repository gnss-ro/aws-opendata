#Adapted from it_pp_wopt_02.pro
#
#Compares input refrac and occ(wopt(refrac)), assuming the former
#is in ofile and the latter is in tfile.
#
#INPUT:
#
#KEYWORDS:
#
#OUTPUT:
#    error            1 [error] 0 [all fine]


from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator, AutoMinorLocator
import numpy as np
import math
from netCDF4 import Dataset
import scipy as sp
import argparse


def it_pp_wopt_02(ofile, tfile):
    if len(ofile) == 0:
        ofile = "../data/ropp_pp_wopt_tool_in.nc"  # observations/input
    if len(tfile) == 0:
        tfile = "ropp_pp_wopt_tool_out.nc"  # output

    ########## Level 2a #########

    print("Reading original file " + ofile)
    odata = Dataset(ofile)
    oalt_refrac = np.array(odata["alt_refrac"])[0]
    orefrac = np.array(odata["refrac"])[0]

    print("Reading output file " + tfile)
    tdata = Dataset(tfile)
    talt_refrac = np.array(tdata["alt_refrac"])[0]
    trefrac = np.array(tdata["refrac"])[0]

    ifail = 0
    no2a = len(oalt_refrac)
    nt2a = len(talt_refrac)

    print("No. Level 2a levels:", no2a, nt2a)

    # Interpolate data onto common levels
    grid2a = np.linspace(min(oalt_refrac), max(oalt_refrac), num=1500)

    trefrac = sp.interpolate.interp1d(
        talt_refrac, trefrac, bounds_error=False, fill_value="extrapolate"
    )(grid2a)
    talt_refrac = sp.interpolate.interp1d(
        talt_refrac, talt_refrac, bounds_error=False, fill_value="extrapolate"
    )(grid2a)

    orefrac = sp.interpolate.interp1d(oalt_refrac, orefrac)(grid2a)
    oalt_refrac = sp.interpolate.interp1d(oalt_refrac, oalt_refrac)(grid2a)

    # Computer maximum differences between data
    diff = max(oalt_refrac - talt_refrac)
    if diff > 0:
        print("alt_refracs differ by ", diff, " m - TEST FAILED")
        ifail = 1
    else:
        print("alt_refracs differ by ", diff, " m - TEST PASSED")

    diff = max(orefrac - trefrac)
    if diff > 0:
        print("refracs differ by ", diff, " N-units - TEST FAILED")
        ifail = 1
    else:
        print("refracs differ by ", diff, " N-units - TEST PASSED")

    
    jpgfile = "ropp_pp_comp2.jpg"

    # Set up plotting
    fig, ax = plt.subplots(figsize=(9,5))
    plt.subplots_adjust( hspace=0)

    # Plot refracx and the diff
    ax.plot(orefrac, grid2a - min(grid2a), label="ref", linestyle=":", linewidth=3)
    ax.plot(trefrac, grid2a - min(grid2a), label="test", marker="+", linewidth=0.5, markersize=1)
    #ax.set_ylim([0.0, 9e4])
    #ax.set_xlim([1e-4, 1e-3])
    ax.set_ylabel("alt refrac (m)")
    ax.set_xlabel("refrac (N-units)")
    ax.set_title("Ref file = " + ofile+ "\nTest file = "+tfile)
    ax.legend(loc=2)

    # second y axis for subplot 1 that shares the x-axis
    ax_twin = ax.twiny()
    #ax_twin.set_xlim([-10, 10])
    ax_twin.plot((trefrac - orefrac), grid2a - min(grid2a), color='red',label=f"test-ref ({int(min(trefrac-orefrac))}  to  {int(max(trefrac-orefrac))})", linestyle="dashed")
    ax_twin.tick_params(axis="x", labelcolor='red')
    ax_twin.set_xlabel("refrac difference (N-units)", color='red')
    ax_twin.legend(loc=1)

    plt.savefig(jpgfile)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ofile", default="", help="file holding observations")
    parser.add_argument("--tfile", default="", help="output file")

    args = parser.parse_args()

    ofile = args.ofile
    tfile = args.tfile

    it_pp_wopt_02(ofile, tfile)
