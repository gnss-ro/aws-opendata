#Python adaption of it_pp_spectra_ep.pro
#
#plot localised spatial spectra as function of impact height and
#bending angle
#
#INPUT:
#
#KEYWORDS:
#    op_format - select output image file type ('X', 'EPS', 'PNG', 'GIF', 'JPG')
#    'EPS' is the default.
#
#OUTPUT:
#
#SEE ALSO:
#    it_pp_spectra.py  (plot spectra time-frequency)  


from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator, AutoMinorLocator
import numpy as np
import math
import argparse


def it_pp_spectra_ep(op_format):
    plotdev = op_format

    # Define input filenames
    try:
        file_R01 = "../data/ROanalysis_ep_L1.dat"
        file_R02 = "../data/ROanalysis_ep_L2.dat"
    except FileNotFoundError:
        # TODO: remove this?
        print(
            "Either one or more of the data files does not exist or you are not in ropp_pp/tests/."
        )

    #####################################
    #     R01
    #####################################
    header = ""
    with open(file_R01, "r") as file:

        # header is first two lines of data file
        foo = next(file)
        header = header + next(file)
        print(header)
        nx = int(header.split()[2])
        ny = int(header.split()[4])

    x1, y1, z1 = np.loadtxt(file_R01, unpack=True, skiprows=2)

    #####################################
    #     R02
    #####################################
    header = ""
    with open(file_R02, "r") as file:

        # header is first two lines of data file
        foo = next(file)
        header = header + next(file)
        print(header)

    x2, y2, z2 = np.loadtxt(file_R02, unpack=True, skiprows=2)

    ###################################
    #   Plotting
    ###################################

    # move plot setup instructions to the bottom
    fig, axs = plt.subplots(ncols=2, sharey=True, sharex=True, figsize=(10, 5))

    axs[0].set_ylabel("Impact height (km)", fontsize=16)
    axs[0].set_xlabel("Bending angle (rad)", fontsize=16)
    axs[1].set_xlabel("Bending angle (rad)", fontsize=16)

    # subplots share x and y-axes, so only have to do this once
    axs[0].set_ylim(-5, 30)
    axs[0].set_xlim(0, 0.05)

    axs[0].set_title("L1", fontsize=20)
    axs[0].contourf(
        x1.reshape((ny, nx)),
        y1.reshape((ny, nx)),
        z1.reshape((ny, nx)),
        vmin=-10,
        levels=20,
    )
    axs[1].set_title("L2", fontsize=20)
    axs[1].contourf(
        x2.reshape((ny, nx)),
        y2.reshape((ny, nx)),
        z2.reshape((ny, nx)),
        vmin=-10,
        levels=20,
    )

    for ax in axs:
        ax.tick_params(axis="both", which="major", labelsize=12, bottom=True, top=True)
        ax.xaxis.set_minor_locator(AutoMinorLocator())

    plt.tight_layout()

    # save plot
    if plotdev == "PNG":
        opfile = "ropp_pp_spectra_ep.png"
    elif plotdev == "EPS":
        opfile = "ropp_pp_spectra_ep.eps"
    elif plotdev == "GIF":
        opfile = "ropp_pp_spectra_ep.gif"
    elif plotdev == "JPEG":
        opfile = "ropp_pp_spectra_ep.jpeg"
    else:
        print("Type of image file needs to be PNG, EPS, GIF, or JPEG.")
        raise TypeError

    print("Plotting to ", opfile, "....")
    plt.savefig(opfile)
    plt.show()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--op_format", default="EPS", help="format for output figure")

    args = parser.parse_args()

    op_format = args.op_format

    it_pp_spectra_ep(op_format)
