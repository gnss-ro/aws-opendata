#Adapted from it_pp_wopt_01.pro
#does a ropp pp WOPT test
#
#INPUT:
#
#KEYWORDS:
#
#OUTPUT:
# error            1 [error] 0 [all fine]
#
#
#file settings


from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator, AutoMinorLocator
import numpy as np
import math
from netCDF4 import Dataset
import scipy as sp
import argparse


def it_pp_wopt_01(ofile, tfile):

    if len(ofile) == 0:
        ofile = "../data/ropp_pp_wopt_tool_in.nc"  # observations/input
    if len(tfile) == 0:
        tfile = "ropp_pp_wopt_tool_out.nc"  # output

    ########## Level 1a #########

    print("Reading original file " + ofile)
    odata = Dataset(ofile)
    odtime = np.array(odata["dtime"])[0]
    osnr = np.array(odata["snr_L1ca"])[0]
    ophase = np.array(odata["phase_L1"])[0]

    print("Reading output file " + tfile)
    tdata = Dataset(tfile)
    tdtime = np.array(tdata["dtime"])[0]
    tsnr = np.array(tdata["snr_L1ca"])[0]
    tphase = np.array(tdata["phase_L1"])[0]

    ifail = 0
    no1a = len(odtime)
    nt1a = len(tdtime)

    print("No. Level 1a levels:", no1a, nt1a)

    # Interpolate data onto common levels
    grid1a = np.linspace(min(odtime), max(odtime), num=1500)

    tsnr = sp.interpolate.interp1d(
        tdtime, tsnr, bounds_error=False, fill_value="extrapolate"
    )(grid1a)
    tphase = sp.interpolate.interp1d(
        tdtime, tphase, bounds_error=False, fill_value="extrapolate"
    )(grid1a)
    tdtime = sp.interpolate.interp1d(
        tdtime, tdtime, bounds_error=False, fill_value="extrapolate"
    )(grid1a)

    osnr = sp.interpolate.interp1d(odtime, osnr)(grid1a)
    ophase = sp.interpolate.interp1d(odtime, ophase)(grid1a)
    odtime = sp.interpolate.interp1d(odtime, odtime)(grid1a)

    # Compute maximum differences between data
    diff = max(odtime - tdtime)
    if diff > 0:
        print("dtime parameters differ by ", diff, " sec - TEST FAILED")
        ifail = 1
    else:
        print("dtime parameters differ by ", diff, " sec - TEST PASSED")

    diff = max(ophase - tphase)
    if diff > 0:
        print("Excess phases differ by ", diff, " m - TEST FAILED")
        ifail = 1
    else:
        print("Excess phases differ by ", diff, " m - TEST PASSED")

    diff = max(osnr - tsnr)
    if diff > 0:
        print("SNRs differ by ", diff, " V/V - TEST FAILED")
        ifail = 1
    else:
        print("SNRs differ by ", diff, " V/V - TEST PASSED")

    jpgfile = "ropp_pp_comp1.jpg"

    # Set up plotting
    fig, axs = plt.subplots(nrows=2, sharex=True, figsize=(9,10))
    plt.subplots_adjust( hspace=0)

    # Plot phase and diff
    axs[0].plot(grid1a - min(grid1a), ophase, label="ref", linestyle=":")
    axs[0].plot(grid1a - min(grid1a), tphase, label="test", marker="+")
    axs[0].set_xlim([0, 100])
    axs[0].set_ylim([0, 4e3])
    axs[0].set_ylabel("Excess phase (m)")
    axs[0].set_title("Ref file = " + ofile+ "\nTest file = "+tfile)
    axs[0].legend()

    # second y axis for subplot 1 that shares the x-axis
    axs0_twin = axs[0].twinx()
    axs0_twin.set_ylim([-1 * max(abs(tphase - ophase)), 1 * max(abs(tphase - ophase))])
    axs0_twin.plot(grid1a - min(grid1a), (tphase - ophase), color='red',label=f"test-ref ({int(min(tphase-ophase))}  to  {int(max(tphase-ophase))})", linestyle="dashed")
    axs0_twin.tick_params(axis="y", labelcolor='red')
    axs0_twin.set_ylabel("Excess phase difference (m)", color='red')
    axs0_twin.legend(loc=1)
    

    # Plot SNR and the diff
    axs[1].plot(grid1a - min(grid1a), osnr, label="ref", linestyle=":")
    axs[1].plot(grid1a - min(grid1a), tsnr, label="test", marker="+")
    axs[1].legend()

    axs1_twin = axs[1].twinx()
    axs1_twin.set_ylim([-1 * max(abs(tsnr - osnr)), 1 * max(abs(tsnr - osnr))])
    axs1_twin.plot(grid1a - min(grid1a), tsnr-osnr, color='red', label=f"test-ref ({int(min(tsnr-osnr))}  to  {int(max(tsnr-osnr))})", linestyle="dashed")
    axs1_twin.tick_params(axis="y", labelcolor='red')
    axs1_twin.set_ylabel("Excess phase difference (m)", color='red')
    axs1_twin.legend(loc=1)4

    axs[1].set_xlim([0, 100])
    axs[1].set_ylim([0, 2])
    axs[1].set_ylabel("SNR (V/V)")

    axs[1].set_xlabel("dtime (s)")

    plt.savefig(jpgfile)

    if ifail == 0:
        print("All tests successful.... TEST PASSED!")
    else:
        print("At least one test failed.... TEST FAILED!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ofile", default="", help="file holding observations")
    parser.add_argument("--tfile", default="", help="output file")

    args = parser.parse_args()

    ofile = args.ofile
    tfile = args.tfile

    it_pp_wopt_01(ofile, tfile)
