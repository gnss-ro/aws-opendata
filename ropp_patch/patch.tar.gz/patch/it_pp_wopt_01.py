"""
Adapted from it_pp_wopt_01.pro
does a ropp pp WOPT test

INPUT:

KEYWORDS:

OUTPUT:
 error            1 [error] 0 [all fine]


file settings

"""

from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator, AutoMinorLocator
import numpy as np
import math
from netCDF4 import Dataset
import scipy as sp
import argparse


def it_pp_wopt_01(ofile, tfile):

    if len(ofile) == 0:
        ofile = "../data/ropp_pp_wopt_tool.nc"  # observations
    if len(tfile) == 0:
        tfile = "ropp_pp_wopt_tool_out.nc"  # output

    ########## Level 1a #########

    print("Reading original file " + ofile)
    odata = Dataset(ofile)
    odtime = np.array(odata["dtime"])[0]
    osnr = np.array(odata["snr_L1ca"])[0]
    ophase = np.array(odata["phase_L1"])[0]

    print("Reading output file " + tfile)
    tdata = Dataset(tfile)
    tdtime = np.array(tdata["dtime"])[0]
    tsnr = np.array(tdata["snr_L1ca"])[0]
    tphase = np.array(tdata["phase_L1"])[0]

    ifail = 0
    no1a = len(odtime)
    nt1a = len(tdtime)

    print("No. Level 1a levels:", no1a, nt1a)

    # Interpolate data onto common levels
    grid1a = np.linspace(min(odtime), max(odtime), num=1500)

    tsnr = sp.interpolate.interp1d(
        tdtime, tsnr, bounds_error=False, fill_value="extrapolate"
    )(grid1a)
    tphase = sp.interpolate.interp1d(
        tdtime, tphase, bounds_error=False, fill_value="extrapolate"
    )(grid1a)
    tdtime = sp.interpolate.interp1d(
        tdtime, tdtime, bounds_error=False, fill_value="extrapolate"
    )(grid1a)

    osnr = sp.interpolate.interp1d(odtime, osnr)(grid1a)
    ophase = sp.interpolate.interp1d(odtime, ophase)(grid1a)
    odtime = sp.interpolate.interp1d(odtime, odtime)(grid1a)

    # Compute maximum differences between data
    diff = max(odtime - tdtime)
    if diff > 0:
        print("dtime parameters differ by ", diff, " sec - TEST FAILED")
        ifail = 1
    else:
        print("dtime parameters differ by ", diff, " sec - TEST PASSED")

    diff = max(ophase - tphase)
    if diff > 0:
        print("Excess phases differ by ", diff, " m - TEST FAILED")
        ifail = 1
    else:
        print("Excess phases differ by ", diff, " m - TEST PASSED")

    diff = max(osnr - tsnr)
    if diff > 0:
        print("SNRs differ by ", diff, " V/V - TEST FAILED")
        ifail = 1
    else:
        print("SNRs differ by ", diff, " V/V - TEST PASSED")

    # TODO: change this name
    jpgfile = "ropp_pp_comp_TEST.jpg"

    # Set up plotting
    fig, axs = plt.subplots(ncols=2, nrows=2, gridspec_kw={"height_ratios": [3, 1]})
    axs[0][0].plot(grid1a - min(grid1a), ophase, label="ophase")
    axs[0][0].plot(grid1a - min(grid1a), tphase, label="tphase")

    # oplot, (grid1a-min(grid1a)), ophase, line=0
    # TODO: Im not sure I've interpreted these lines correctly but...
    # ... but don't have a sample figure to compare
    # oplot, [5, 15], [3.75e3, 3.75e3], line=0  &  xyouts, 20, 3.75e3, /data, 'ref'
    # oplot, [5, 15], [3.50e3, 3.50e3], psym=1  &  xyouts, 20, 3.50e3, /data, 'test'
    # oplot, [5, 15], [3.25e3, 3.25e3], line=2  &  xyouts, 20, 3.25e3, /data, 'test-ref', xyouts, 20, 3.00e3, /data, '('+string(min(tphase - ophase),'(f7.1)')+' to '+string(max(tphase - ophase),'(f7.1)')+')
    # oplot, ((grid1a-min(grid1a)))(25*indgen(60)), tphase(25*indgen(60)), psym=1
    axs[0][0].plot([5, 15], [3.75e3, 3.75e3], label="ref", marker="*")
    axs[0][0].plot([5, 15], [3.50e3, 3.50e3], label="test", marker="*")
    axs[0][0].plot([5, 15], [3.25e3, 3.25e3], label="test-ref")
    axs[0][0].set_xlim([0, 100])
    axs[0][0].set_ylim([0, 4e3])
    axs[0][0].set_ylabel("Excess phase (m)")
    axs[0][0].set_title("Ref file = " + ofile)
    axs[0][0].legend()

    # axis, yaxis=1, yrange=[-1,1]*(max(abs(tphase-ophase)) > 1), ystyle=1, ytit='Excess phase difference (m)', /save
    # oplot, (grid1a-min(grid1a)), (tphase - ophase), line=2
    axs[0][1].plot(grid1a - min(grid1a), (tphase - ophase))
    # yrange=[-1,1]*(max(abs(tphase-ophase)) > 1)
    axs[0][1].set_ylim([-1 * max(abs(tphase - ophase)), 1 * max(abs(tphase - ophase))])
    axs[0][1].set_ylabel("Excess phase difference (m)")
    axs[0][1].set_xlabel("dtime (s)")

    # Plot SNR and the diff
    axs[1][0].plot(grid1a - min(grid1a), osnr, label="osnr")
    # oplot, ((grid1a-min(grid1a)))(25*indgen(60)), tsnr(25*indgen(60)), psym=1
    axs[1][0].plot(grid1a - min(grid1a), tsnr, label="tsnr")

    # oplot, [5, 15], [1.875, 1.875], line=0  &  xyouts, 20, 1.875, /data, 'ref'
    # oplot, [5, 15], [1.750, 1.750], psym=1  &  xyouts, 20, 1.750, /data, 'test'
    # oplot, [5, 15], [1.625, 1.625], line=2  &  xyouts, 20, 1.625, /data, 'test-ref'
    #                                      xyouts, 20, 1.500, /data, '('+string(min(tsnr - osnr),'(f7.3)')+' to '+string(max(tsnr - osnr),'(f7.3)')+')
    axs[1][0].plot([5, 15], [1.875, 1.875], marker="*")
    axs[1][0].text(20, 3.75e3, "ref")
    axs[1][0].plot([5, 15], [1.750, 1.750], marker="*")
    axs[1][0].text(20, 1.750, "test")
    axs[1][0].plot([5, 15], [1.625, 1.625])
    axs[1][0].text(20, 1.625, "test-ref")

    axs[1][0].set_xlim([0, 100])
    axs[1][0].set_ylim([0, 2])
    axs[1][0].set_ylabel("SNR (V/V)")

    axs[1][1].set_xlabel("dtime (s)")

    plt.savefig(jpgfile)

    if ifail == 0:
        print("All tests successful.... TEST PASSED!")
    else:
        print("At least one test failed.... TEST FAILED!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ofile", default="", help="file holding observations")
    parser.add_argument("--tfile", default="", help="output file")

    args = parser.parse_args()

    ofile = args.ofile
    tfile = args.tfile

    it_pp_wopt_01(ofile, tfile)
