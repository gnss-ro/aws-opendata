"""
Adapted from it_pp_wopt_02.pro

Compares input refrac and occ(wopt(refrac)), assuming the former
is in ofile and the latter is in tfile.

INPUT:

KEYWORDS:

OUTPUT:
    error            1 [error] 0 [all fine]

"""

from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator, AutoMinorLocator
import numpy as np
import math
from netCDF4 import Dataset
import scipy as sp
import argparse


def it_pp_wopt_02(ofile, tfile):
    if len(ofile) == 0:
        ofile = "../data/ropp_pp_wopt_tool.nc"  # observations
    if len(tfile) == 0:
        tfile = "ropp_pp_wopt_tool_out.nc"  # output

    ########## Level 2a #########

    print("Reading original file " + ofile)
    odata = Dataset(ofile)
    oalt_refrac = np.array(odata["alt_refrac"])[0]
    orefrac = np.array(odata["refrac"])[0]

    print("Reading output file " + tfile)
    tdata = Dataset(tfile)
    talt_refrac = np.array(tdata["alt_refrac"])[0]
    trefrac = np.array(tdata["refrac"])[0]

    ifail = 0
    no2a = len(oalt_refrac)
    nt2a = len(talt_refrac)

    print("No. Level 2a levels:", no2a, nt2a)

    # Interpolate data onto common levels
    grid2a = np.linspace(min(oalt_refrac), max(oalt_refrac), num=1500)

    trefrac = sp.interpolate.interp1d(
        talt_refrac, trefrac, bounds_error=False, fill_value="extrapolate"
    )(grid2a)
    talt_refrac = sp.interpolate.interp1d(
        talt_refrac, talt_refrac, bounds_error=False, fill_value="extrapolate"
    )(grid2a)

    orefrac = sp.interpolate.interp1d(oalt_refrac, orefrac)(grid2a)
    oalt_refrac = sp.interpolate.interp1d(oalt_refrac, oalt_refrac)(grid2a)

    # Computer maximum differences between data
    diff = max(oalt_refrac - talt_refrac)
    if diff > 0:
        print("alt_refracs differ by ", diff, " m - TEST FAILED")
        ifail = 1
    else:
        print("alt_refracs differ by ", diff, " m - TEST PASSED")

    diff = max(orefrac - trefrac)
    if diff > 0:
        print("refracs differ by ", diff, " N-units - TEST FAILED")
        ifail = 1
    else:
        print("refracs differ by ", diff, " N-units - TEST PASSED")

    # TODO: change this name
    jpgfile = "ropp_pp_comp_TEST2.jpg"

    # Plot refracs and the diff
    fig, axs = plt.subplots(ncols=2, nrows=2, gridspec_kw={"height_ratios": [3, 1]})
    axs[0][0].plot(grid2a - min(grid2a), orefrac, label="orefrac")
    axs[0][0].plot(grid2a - min(grid2a), trefrac, label="trefrac")
    axs[0][0].set_ylabel("alt refrac (m)")
    axs[0][0].set_ylabel("refrac (N-units)")
    axs[0][0].set_title("Ref file = " + ofile)
    axs[0][0].set_xlim([1e-4, 1e3])

    #### TODO: flesh the rest of this out after figuring out it_pp_wopt_01
    plt.savefig(jpgfile)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ofile", default="", help="file holding observations")
    parser.add_argument("--tfile", default="", help="output file")

    args = parser.parse_args()

    ofile = args.ofile
    tfile = args.tfile

    it_pp_wopt_02(ofile, tfile)
